import { useCallback, useEffect, useRef, useState } from "react";

const WORLD = { width: 1800, height: 1200 };
const PLAYER_SPEED = 235;
const ENEMY_SPAWNS = 9;

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}
function distance(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}
function makeEnemy(id, x, y) {
  return {
    id, x, y, radius: 17, hp: 48, maxHp: 48, speed: 58 + Math.random() * 23,
    attackCooldown: 0, hitFlash: 0, dead: false
  };
}
function makeInitialEnemies() {
  const enemies = [];
  for (let i = 0; i < ENEMY_SPAWNS; i++) {
    const angle = (Math.PI * 2 * i) / ENEMY_SPAWNS;
    enemies.push(makeEnemy(i + 1, WORLD.width / 2 + Math.cos(angle) * (270 + (i % 3) * 60),
      WORLD.height / 2 + Math.sin(angle) * (220 + (i % 2) * 80)));
  }
  return enemies;
}

export default function App() {
  const canvasRef = useRef(null);
  const gameRef = useRef(null);
  const keysRef = useRef({});
  const mouseRef = useRef({ x: 0, y: 0, down: false });
  const [hud, setHud] = useState({ hp: 100, maxHp: 100, energy: 100, kills: 0, remaining: ENEMY_SPAWNS, wave: 1 });
  const [message, setMessage] = useState("Clear the area. Don't let them surround you.");
  const [paused, setPaused] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [victory, setVictory] = useState(false);

  const resetGame = useCallback(() => {
    gameRef.current = {
      player: { x: WORLD.width / 2, y: WORLD.height / 2, radius: 15, hp: 100, maxHp: 100,
        energy: 100, invuln: 0, attackCooldown: 0, dashCooldown: 0, pulseCooldown: 0,
        dashTime: 0, facingX: 1, facingY: 0, kills: 0 },
      enemies: makeInitialEnemies(),
      projectiles: [],
      particles: [],
      camera: { x: 0, y: 0 },
      lastTime: 0,
      nextEnemyId: ENEMY_SPAWNS + 1,
      attackFlash: 0,
      pulseFlash: 0,
      elapsed: 0,
      lastHud: 0
    };
    keysRef.current = {};
    mouseRef.current.down = false;
    setHud({ hp: 100, maxHp: 100, energy: 100, kills: 0, remaining: ENEMY_SPAWNS, wave: 1 });
    setMessage("Clear the area. Don't let them surround you.");
    setPaused(false);
    setGameOver(false);
    setVictory(false);
  }, []);

  useEffect(() => { resetGame(); }, [resetGame]);

  useEffect(() => {
    const down = (event) => {
      const key = event.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(key)) event.preventDefault();
      keysRef.current[key] = true;
      if (key === "escape") setPaused(p => !p);
      if (key === "r" && (gameOver || victory)) resetGame();
    };
    const up = (event) => { keysRef.current[event.key.toLowerCase()] = false; };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, [gameOver, victory, resetGame]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    let raf = 0;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const rect = canvas.getBoundingClientRect();
      canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    const toWorldMouse = () => {
      const rect = canvas.getBoundingClientRect();
      return {
        x: mouseRef.current.x - rect.left + gameRef.current.camera.x,
        y: mouseRef.current.y - rect.top + gameRef.current.camera.y
      };
    };
    const spawnParticles = (g, x, y, color, amount = 10) => {
      for (let i = 0; i < amount; i++) {
        const a = Math.random() * Math.PI * 2;
        const speed = 35 + Math.random() * 150;
        g.particles.push({ x, y, vx: Math.cos(a) * speed, vy: Math.sin(a) * speed,
          life: 0.25 + Math.random() * 0.45, maxLife: 0.7, color, size: 2 + Math.random() * 3 });
      }
    };

    const frame = (time) => {
      raf = requestAnimationFrame(frame);
      const g = gameRef.current;
      if (!g) return;
      const rect = canvas.getBoundingClientRect();
      const w = rect.width, h = rect.height;
      const dt = Math.min(g.lastTime ? (time - g.lastTime) / 1000 : 0, 0.033);
      g.lastTime = time;
      if (!paused && !gameOver && !victory) {
        g.elapsed += dt;
        const p = g.player;
        const keys = keysRef.current;
        let dx = (keys.d || keys.arrowright ? 1 : 0) - (keys.a || keys.arrowleft ? 1 : 0);
        let dy = (keys.s || keys.arrowdown ? 1 : 0) - (keys.w || keys.arrowup ? 1 : 0);
        const mag = Math.hypot(dx, dy);
        if (mag > 0) { dx /= mag; dy /= mag; p.facingX = dx; p.facingY = dy; }
        p.energy = clamp(p.energy + 17 * dt, 0, 100);
        p.invuln = Math.max(0, p.invuln - dt);
        p.attackCooldown = Math.max(0, p.attackCooldown - dt);
        p.dashCooldown = Math.max(0, p.dashCooldown - dt);
        p.pulseCooldown = Math.max(0, p.pulseCooldown - dt);
        p.dashTime = Math.max(0, p.dashTime - dt);
        g.attackFlash = Math.max(0, g.attackFlash - dt);
        g.pulseFlash = Math.max(0, g.pulseFlash - dt);

        if (keys.shift && p.dashCooldown <= 0 && p.energy >= 22) {
          p.energy -= 22; p.dashCooldown = 1.25; p.dashTime = 0.16; p.invuln = 0.24;
          spawnParticles(g, p.x, p.y, "#7de9ff", 15);
          keys.shift = false;
        }
        if (keys.q && p.pulseCooldown <= 0 && p.energy >= 42) {
          p.energy -= 42; p.pulseCooldown = 4.5; g.pulseFlash = 0.45;
          for (const e of g.enemies) {
            if (!e.dead && distance(p, e) < 185) {
              e.hp -= 42; e.hitFlash = 0.18;
              const len = Math.max(1, distance(p, e));
              e.x += ((e.x - p.x) / len) * 75;
              e.y += ((e.y - p.y) / len) * 75;
              spawnParticles(g, e.x, e.y, "#a4f5ff", 12);
            }
          }
          spawnParticles(g, p.x, p.y, "#5fe6ff", 35);
          setMessage("PULSE RELEASED");
          keys.q = false;
        }
        if ((mouseRef.current.down || keys[" "]) && p.attackCooldown <= 0) {
          const aim = toWorldMouse();
          let ax = aim.x - p.x, ay = aim.y - p.y;
          let len = Math.hypot(ax, ay);
          if (len < 8) { ax = p.facingX; ay = p.facingY; len = Math.max(1, Math.hypot(ax, ay)); }
          ax /= len; ay /= len;
          p.facingX = ax; p.facingY = ay;
          g.projectiles.push({ x: p.x + ax * 22, y: p.y + ay * 22, vx: ax * 520, vy: ay * 520,
            radius: 6, life: 1.1, damage: 25 });
          p.attackCooldown = 0.24;
          g.attackFlash = 0.08;
        }
        const speed = PLAYER_SPEED * (p.dashTime > 0 ? 3.3 : 1);
        p.x = clamp(p.x + dx * speed * dt, 24, WORLD.width - 24);
        p.y = clamp(p.y + dy * speed * dt, 24, WORLD.height - 24);

        for (const e of g.enemies) {
          if (e.dead) continue;
          e.hitFlash = Math.max(0, e.hitFlash - dt);
          e.attackCooldown = Math.max(0, e.attackCooldown - dt);
          const ex = p.x - e.x, ey = p.y - e.y, len = Math.max(1, Math.hypot(ex, ey));
          if (len > p.radius + e.radius + 5) {
            e.x += (ex / len) * e.speed * dt;
            e.y += (ey / len) * e.speed * dt;
          } else if (e.attackCooldown <= 0 && p.invuln <= 0) {
            p.hp = Math.max(0, p.hp - 9);
            p.invuln = 0.55;
            e.attackCooldown = 0.85;
            spawnParticles(g, p.x, p.y, "#ff526b", 8);
            setMessage("You're taking damage — keep moving!");
          }
          if (e.hp <= 0) {
            e.dead = true; p.kills++;
            spawnParticles(g, e.x, e.y, "#ff5670", 18);
          }
        }

        for (const b of g.projectiles) {
          b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
          for (const e of g.enemies) {
            if (e.dead || b.life <= 0) continue;
            if (Math.hypot(b.x - e.x, b.y - e.y) < b.radius + e.radius) {
              e.hp -= b.damage; e.hitFlash = 0.12; b.life = 0;
              spawnParticles(g, b.x, b.y, "#8aefff", 6);
            }
          }
        }
        g.projectiles = g.projectiles.filter(b => b.life > 0 && b.x > 0 && b.y > 0 && b.x < WORLD.width && b.y < WORLD.height);
        for (const part of g.particles) {
          part.x += part.vx * dt; part.y += part.vy * dt;
          part.vx *= 0.97; part.vy *= 0.97; part.life -= dt;
        }
        g.particles = g.particles.filter(part => part.life > 0);
        g.camera.x = clamp(p.x - w / 2, 0, WORLD.width - w);
        g.camera.y = clamp(p.y - h / 2, 0, WORLD.height - h);
        if (p.hp <= 0) { setGameOver(true); setMessage("The darkness caught up with you."); }
        if (g.enemies.every(e => e.dead)) { setVictory(true); setMessage("Area cleared. You survived the night."); }
        if (time - g.lastHud > 100) {
          setHud({ hp: Math.ceil(p.hp), maxHp: p.maxHp, energy: Math.floor(p.energy), kills: p.kills,
            remaining: g.enemies.filter(e => !e.dead).length, wave: 1 });
          g.lastHud = time;
        }
      }

      // Background and camera transform
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = "#0a0d13"; ctx.fillRect(0, 0, w, h);
      ctx.save(); ctx.translate(-g.camera.x, -g.camera.y);

      // Ground tiles
      const tile = 64;
      const startX = Math.floor(g.camera.x / tile) * tile;
      const startY = Math.floor(g.camera.y / tile) * tile;
      for (let x = startX; x < g.camera.x + w + tile; x += tile) {
        for (let y = startY; y < g.camera.y + h + tile; y += tile) {
          ctx.fillStyle = ((x / tile + y / tile) % 2 === 0) ? "#111720" : "#0f151d";
          ctx.fillRect(x, y, tile - 1, tile - 1);
          if ((x * 7 + y * 3) % 11 === 0) {
            ctx.fillStyle = "#1c2630"; ctx.fillRect(x + 14, y + 19, 2, 2);
          }
        }
      }
      // Cracked road strips
      ctx.fillStyle = "#141923";
      ctx.fillRect(0, 560, WORLD.width, 78);
      ctx.fillRect(860, 0, 82, WORLD.height);
      ctx.strokeStyle = "#303440"; ctx.lineWidth = 2; ctx.setLineDash([18, 18]);
      ctx.beginPath(); ctx.moveTo(0, 599); ctx.lineTo(WORLD.width, 599); ctx.moveTo(901, 0); ctx.lineTo(901, WORLD.height); ctx.stroke(); ctx.setLineDash([]);

      // Broken barriers / debris
      const obstacles = [
        [260,220,120,30],[520,350,32,140],[1150,240,140,28],[1390,490,36,120],
        [350,850,150,32],[760,900,36,110],[1220,810,120,32],[1490,990,90,26],
        [1040,440,70,30],[560,680,80,24],[150,500,30,95],[1630,300,90,28]
      ];
      for (const [x,y,ow,oh] of obstacles) {
        ctx.fillStyle = "#202a34"; ctx.fillRect(x,y,ow,oh);
        ctx.strokeStyle = "#3c4855"; ctx.lineWidth = 2; ctx.strokeRect(x+3,y+3,ow-6,oh-6);
        ctx.fillStyle = "#10151c"; ctx.fillRect(x+8,y+8,Math.max(3,ow-16),Math.max(3,oh-16));
      }
      // Pools of eerie light
      for (const [x,y,r] of [[330,400,110],[1250,660,130],[900,180,90],[1510,850,100]]) {
        const grad = ctx.createRadialGradient(x,y,0,x,y,r);
        grad.addColorStop(0,"rgba(44,102,133,0.12)"); grad.addColorStop(1,"rgba(44,102,133,0)");
        ctx.fillStyle = grad; ctx.fillRect(x-r,y-r,r*2,r*2);
      }

      // Enemies
      for (const e of g.enemies) {
        if (e.dead) continue;
        ctx.save();
        ctx.shadowBlur = 20; ctx.shadowColor = e.hitFlash ? "#ffffff" : "#e83d62";
        ctx.fillStyle = e.hitFlash ? "#ffffff" : "#75283d";
        ctx.beginPath(); ctx.arc(e.x,e.y,e.radius,0,Math.PI*2); ctx.fill();
        ctx.shadowBlur = 0;
        ctx.fillStyle = "#17101a"; ctx.beginPath(); ctx.arc(e.x,e.y,7,0,Math.PI*2); ctx.fill();
        ctx.fillStyle = "#ff9ca9"; ctx.fillRect(e.x-7,e.y-3,4,3); ctx.fillRect(e.x+3,e.y-3,4,3);
        ctx.fillStyle = "#26151f"; ctx.fillRect(e.x-19,e.y-28,38,5);
        ctx.fillStyle = "#f04c69"; ctx.fillRect(e.x-19,e.y-28,38*clamp(e.hp/e.maxHp,0,1),5);
        ctx.restore();
      }
      // Projectiles
      for (const b of g.projectiles) {
        ctx.save(); ctx.shadowBlur = 20; ctx.shadowColor = "#61eaff";
        ctx.fillStyle = "#b9f7ff"; ctx.beginPath(); ctx.arc(b.x,b.y,b.radius,0,Math.PI*2); ctx.fill(); ctx.restore();
      }
      // Particles
      for (const part of g.particles) {
        ctx.globalAlpha = clamp(part.life / part.maxLife,0,1);
        ctx.fillStyle = part.color; ctx.fillRect(part.x,part.y,part.size,part.size);
      }
      ctx.globalAlpha = 1;

      // Player and ability rings
      const p = g.player;
      if (g.pulseFlash > 0) {
        ctx.strokeStyle = `rgba(103,232,255,${g.pulseFlash * 1.8})`; ctx.lineWidth = 5;
        ctx.beginPath(); ctx.arc(p.x,p.y,185 * (1 - g.pulseFlash / 0.45),0,Math.PI*2); ctx.stroke();
      }
      ctx.save();
      ctx.globalAlpha = p.invuln > 0 && Math.floor(performance.now()/70)%2 === 0 ? 0.35 : 1;
      ctx.shadowBlur = 22; ctx.shadowColor = "#4edcf5";
      ctx.fillStyle = "#54d9ed"; ctx.beginPath(); ctx.arc(p.x,p.y,p.radius,0,Math.PI*2); ctx.fill();
      ctx.shadowBlur = 0;
      ctx.fillStyle = "#e6fcff"; ctx.beginPath(); ctx.arc(p.x-4,p.y-5,5,0,Math.PI*2); ctx.fill();
      ctx.strokeStyle = "#b4f6ff"; ctx.lineWidth = 4; ctx.beginPath();
      ctx.moveTo(p.x,p.y); ctx.lineTo(p.x+p.facingX*27,p.y+p.facingY*27); ctx.stroke();
      ctx.restore();
      ctx.restore();

      // Darkness vignette
      const vignette = ctx.createRadialGradient(w/2,h/2,Math.min(w,h)*0.18,w/2,h/2,Math.max(w,h)*0.72);
      vignette.addColorStop(0,"rgba(0,0,0,0)");
      vignette.addColorStop(1,"rgba(0,0,0,0.72)");
      ctx.fillStyle = vignette; ctx.fillRect(0,0,w,h);
    };

    raf = requestAnimationFrame(frame);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, [paused, gameOver, victory]);

  const updateMouse = (event) => {
    const rect = canvasRef.current.getBoundingClientRect();
    mouseRef.current.x = event.clientX;
    mouseRef.current.y = event.clientY;
    if (event.type === "pointerdown") mouseRef.current.down = true;
    if (event.type === "pointerup" || event.type === "pointerleave") mouseRef.current.down = false;
  };

  const percent = (value, max) => `${clamp((value / max) * 100, 0, 100)}%`;

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand-mark"><span className="brand-symbol">S</span><div><div className="brand-name">SHOWN</div><div className="brand-subtitle">NIGHT SHIFT // PROTOTYPE</div></div></div>
        <div className="top-status"><span className="status-dot" /> SIGNAL UNSTABLE <span className="top-divider">/</span> SECTOR 01</div>
        <button className="pause-button" onClick={() => setPaused(p => !p)}>{paused ? "▶ RESUME" : "Ⅱ PAUSE"}</button>
      </header>

      <section className="game-layout">
        <aside className="side-panel">
          <div className="panel-label">OPERATIVE STATUS</div>
          <div className="portrait"><div className="portrait-glow" /><div className="portrait-person"><span /></div><div className="portrait-tag">SUBJECT 07</div></div>
          <div className="stat-heading"><span>VITALS</span><span>{hud.hp}/{hud.maxHp}</span></div>
          <div className="meter health"><div style={{ width: percent(hud.hp, hud.maxHp) }} /></div>
          <div className="stat-heading energy-heading"><span>PALE ENERGY</span><span>{hud.energy}%</span></div>
          <div className="meter energy"><div style={{ width: `${hud.energy}%` }} /></div>
          <div className="side-separator" />
          <div className="mini-stat"><span>THREATS REMAINING</span><strong>{String(hud.remaining).padStart(2, "0")}</strong></div>
          <div className="mini-stat"><span>ELIMINATIONS</span><strong>{String(hud.kills).padStart(2, "0")}</strong></div>
          <div className="mini-stat"><span>SECTOR</span><strong>01 <small>/ 01</small></strong></div>
          <div className="objective"><div className="objective-icon">!</div><div><b>PRIMARY OBJECTIVE</b><p>Eliminate every hostile entity in the area.</p></div></div>
        </aside>

        <div className="center-column">
          <div className="arena-header"><div><span className="tiny-kicker">LIVE FEED</span><h1>THE ABANDONED DISTRICT</h1></div><div className="coords">X: 0901 <span>Y: 0600</span></div></div>
          <div className="canvas-wrap">
            <canvas ref={canvasRef} onPointerMove={updateMouse} onPointerDown={updateMouse} onPointerUp={updateMouse} onPointerLeave={updateMouse} />
            <div className="arena-corner top-left" /><div className="arena-corner top-right" /><div className="arena-corner bottom-left" /><div className="arena-corner bottom-right" />
            <div className="location-pill"><span className="status-dot red" /> HOSTILE ZONE</div>
            <div className="feed-message">{message}</div>
            {paused && <div className="overlay"><div className="overlay-card"><div className="overlay-eyebrow">SYSTEM HALTED</div><h2>PAUSED</h2><p>Take a breath. The shadows can wait.</p><button className="primary-button" onClick={() => setPaused(false)}>RESUME OPERATION</button></div></div>}
            {(gameOver || victory) && <div className="overlay"><div className="overlay-card"><div className="overlay-eyebrow">{victory ? "MISSION COMPLETE" : "SIGNAL LOST"}</div><h2>{victory ? "AREA CLEARED" : "YOU WERE FOUND"}</h2><p>{victory ? "Every hostile entity has been eliminated." : "You were overwhelmed by the entities."}<br />Eliminations: {hud.kills}</p><button className="primary-button" onClick={resetGame}>↻ RESTART RUN</button><span className="restart-hint">OR PRESS R</span></div></div>}
          </div>
          <div className="arena-footer"><span><i className="key-dot" /> LIVE RENDER</span><span>FRAME FEED <b>ACTIVE</b></span><span>BUILD 0.1.0 // LOCAL</span></div>
        </div>

        <aside className="right-panel">
          <div className="panel-label">ABILITY LOADOUT</div>
          <div className="ability-card">
            <div className="ability-top"><div className="ability-icon bolt">ϟ</div><span className="ability-key">LMB / SPACE</span></div>
            <h3>PALE SHARD</h3><p>Launch a focused bolt of unstable energy.</p><div className="ability-meta"><span>TYPE <b>RANGED</b></span><span>CD <b>0.24s</b></span></div>
          </div>
          <div className="ability-card">
            <div className="ability-top"><div className="ability-icon pulse">◎</div><span className="ability-key">Q</span></div>
            <h3>VOID PULSE</h3><p>Blast nearby enemies with an energy shockwave.</p><div className="ability-meta"><span>TYPE <b>AREA</b></span><span>CD <b>4.5s</b></span></div>
            <div className="ability-cost">− 42 ENERGY</div>
          </div>
          <div className="ability-card">
            <div className="ability-top"><div className="ability-icon dash">»</div><span className="ability-key">SHIFT</span></div>
            <h3>PHASE DASH</h3><p>Surge forward and briefly evade damage.</p><div className="ability-meta"><span>TYPE <b>MOBILITY</b></span><span>CD <b>1.25s</b></span></div>
            <div className="ability-cost">− 22 ENERGY</div>
          </div>
          <div className="controls-box"><div className="panel-label">FIELD CONTROLS</div><div className="control-row"><span><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd></span><label>MOVE</label></div><div className="control-row"><span><kbd>CLICK</kbd></span><label>AIM / FIRE</label></div><div className="control-row"><span><kbd>ESC</kbd></span><label>PAUSE</label></div></div>
        </aside>
      </section>
      <footer className="page-footer"><span>SHOWN // FAN-MADE PROTOTYPE</span><span>THIS IS AN ORIGINAL PLAYABLE DEMO INSPIRED BY A HORROR-ACTION STYLE.</span><span>STAY IN THE LIGHT.</span></footer>
    </main>
  );
}
