# SHOWN — Night Shift (React prototype)

A small, original top-down horror-action prototype inspired by the requested style. It is not an official SHOWN game or an official adaptation.

## Requirements
- Node.js (LTS recommended)
- VS Code

## Run it
1. Extract the ZIP.
2. Open the `shown-game` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL Vite prints, usually `http://localhost:5173`.

## Controls
- **WASD / Arrow keys**: Move
- **Mouse**: Aim
- **Left mouse button**: Fire Pale Shards
- **Space**: Fire toward the mouse / facing direction
- **Q**: Void Pulse area attack (costs 42 energy)
- **Shift**: Phase Dash (costs 22 energy and briefly avoids damage)
- **Esc**: Pause
- **R**: Restart after winning or losing

## Files
- `src/App.jsx`: Game loop, rendering, enemies, combat, HUD and controls.
- `src/App.css`: Visual design and responsive layout.
- `src/main.jsx`: React entry point.
- `index.html`: Browser page shell.
- `package.json`: Project dependencies and scripts.

## Notes
This first prototype uses Canvas shapes instead of downloaded sprites so it runs without an asset pack. Google Fonts are optional; the page still works if they cannot load. The prototype uses simple enemy pursuit and does not yet include collision with the decorative barriers, sound, saved progress, or multiple levels.
